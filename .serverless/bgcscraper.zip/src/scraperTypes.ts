export type ProductProps = {
    categoria: string;
    name: string;
    price: string;
  };