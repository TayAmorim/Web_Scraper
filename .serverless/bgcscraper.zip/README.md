# BGC_Scraper
Desenvolvimento de um Sistema de Web Scraping e API usando Node.js/TypeScript + AWS + Serverless Framework
